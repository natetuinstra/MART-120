var playerx = 50;
var playery = 50;
//obstacles
var o1x = 740;
var o1y = 362.5;
var o2x = 740;
var o2y = 362.5;
var o3x = 740;
var o3y = 362.5;

var moveo1x;
var moveo1y;
var moveo2x;
var moveo2y;
var moveo3x;
var moveo3y;

var mousex = -50;
var mousey = -50;

var winx = -50;
var winy = -50;

function setup()
{
    createCanvas(1480,725);
    moveo1x = (random(-7,7));
    moveo1y = (random(-7,7));
    moveo2x = (random(-5,5));
    moveo2y = (random(-5,5));
    moveo3x = (random(-3,3));
    moveo3y = (random(-3,3));
}

function draw()
{
    background(0);
//player
    fill(151,222,219)
    circle(playerx,playery,10);
//exit
    fill(255,255,255)
    ellipse(1480,675,30,60);
    textSize(20);
    text('exit. -->',1390,680);
//sheild (mouse placement)
    fill(255,255,255)
    square(mousex,mousey,50)
//obstacles
    fill(255,0,0);
    circle(o1x,o1y,20);
    fill(255,165,0);
    circle(o2x,o2y,40);
    fill(255,255,0);
    circle(o3x,o3y,60);
//player movement (x)
    if (keyIsDown(65)) {
        playerx -= 2;
      } else if (keyIsDown(68)) {
        playerx += 2;
      }
//player movement (y)
    if (keyIsDown(87)) {
        playery -= 2;
      } else if (keyIsDown(83)) {
        playery += 2;
      }
//obstacle movement (1)
    if (o1x>= 1480) {
        //moveo1x-= 1480;
        o1x=0;
    }
    else if(o1x<= 0) {
        //moveo1x+= 1480;
        o1x=1480;
    }
    o1x +=moveo1x;

    if (o1y>= 725) {
        o1y=0;
    }
    else if(o1y<= 0) {
        o1y=725;
    }
    o1y +=moveo1y;
//obstacle movement (2)
    if (o2x>= 1480) {
        o2x=0;
    }
    else if(o2x<= 0) {
        o2x=1480;
    }
    o2x +=moveo2x;

    if (o2y>= 725) {
        o2y=0;
    }
    else if(o2y<= 0) {
        o2y=725;
    }
    o2y +=moveo2y;
//obstacle movement (3)
    if (o3x>= 1480) {
        o3x=0;
    }
    else if(o3x<= 0) {
        o3x=1480;
    }
    o3x +=moveo3x;

    if (o3y>= 725) {
        o3y=0;
    }
    else if(o3y<= 0) {
        o3y=725;
    }
    o3y +=moveo3y;
//win text
    textSize(50);
    text("You Escaped",winx,winy);
//win detection
    if (playerx>=1465 && playerx<=1495)
    {
        winx = 570
        winy = 362.5
    }
}
//player dash
function keyPressed(){
    if (key == " " && keyIsDown(65))
    {
        playerx-=20;
    }
    else if(key == " " && keyIsDown(68))
    {
        playerx+=20;
    }
    else if(key == " " && keyIsDown(87))
    {
        playery-=20;
    }
    else if(key == " " && keyIsDown(83))
    {
        playery+=20;
    }
}
//mouse place
function mousePressed()
{
    mousex = mouseX;
    mousey = mouseY;
}