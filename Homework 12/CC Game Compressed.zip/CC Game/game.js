var playerx = 50;
var playery = 50;

var o1x = 740;
var o1y = 362.5;
var o2x = 740;
var o2y = 362.5;
var o3x = 740;
var o3y = 362.5;

var moveo1x;
var moveo1y;
var moveo2x;
var moveo2y;
var moveo3x;
var moveo3y;

var mousex = -50;
var mousey = -50;

var winx = -50;
var winy = -50;

function setup()
{
    createCanvas(1480,725);
    moveo1x = (random(-7,7));
    moveo1y = (random(-7,7));
    moveo2x = (random(-5,5));
    moveo2y = (random(-5,5));
    moveo3x = (random(-3,3));
    moveo3y = (random(-3,3));
}

function draw()
{
    background(0);

//calls border
    border(50,50,50, 0,0,1480,10, 1470,0,10,725, 0,715,1480,10, 0,0,10,715)
//calls player
    player(151,200,250,playerx,playery,10)

//calls player movement
    playerMove(83,65,87,68,2)

//calls sheild (mouse placement)
    sheild(255,255,255,mousex,mousey,50)
    //fill(255,255,255);
    //square(mousex,mousey,50);

//calls obstacles
obstacles(255,0,0,o1x,o1y,20,255,165,0,o2x,o2y,40,255,255,0,o3x,o3y,60)

//calls obstacle movement (1)
o1movement(1480,0,725,0)

//calls obstacle movement (2)
o2movement(1480,0,725,0)
    
//calls obstacle movement (3)
o3movement(1480,0,725,0)

//calls exit
    exit(255,255,255,1480,675,30,60,20,1390,680);

//calls win detection
winDetection(playerx,1465,1495,playery,645,705)

//calls win 
win(50,winx,winy)
}
//^end of draw function^

//border
function border(red,green,blue,x1,y1,length1,width1,x2,y2,length2,width2,x3,y3,length3,width3,x4,y4,length4,width4){
fill(red,green,blue);
rect(x1,y1,length1,width1);
rect(x2,y2,length2,width2);
rect(x3,y3,length3,width3);
rect(x4,y4,length4,width4);
}

//player
function player(red,green,blue,x,y,diameter){
    fill(red,green,blue);
    circle(x,y,diameter);
}

//player movement
function playerMove(w,a,s,d,speed){
    if (keyIsDown(a)) {
        playerx -= speed;
      } else if (keyIsDown(d)) {
        playerx += speed;
      }

      if (keyIsDown(s)) {
        playery -= speed;
      } else if (keyIsDown(w)) {
        playery += speed;
      }
}

//player dash
function keyPressed(){
    if (key == " " && keyIsDown(65))
    {
        playerx-=20;
    }
    else if(key == " " && keyIsDown(68))
    {
        playerx+=20;
    }
    else if(key == " " && keyIsDown(87))
    {
        playery-=20;
    }
    else if(key == " " && keyIsDown(83))
    {
        playery+=20;
    }
}

//mouse place (sheild)
function sheild(red,green,blue,x,y,size){
    fill(red,green,blue);
    square(x,y,size);
}
function mousePressed()
{
    mousex = mouseX;
    mousey = mouseY;
}

//obstacles
function obstacles(r1,g1,b1,x1,y1,diameter1,r2,g2,b2,x2,y2,diameter2,r3,g3,b3,x3,y3,diameter3){
    fill(r1,g1,b1);
    circle(x1,y1,diameter1);
    fill(r2,g2,b2);
    circle(x2,y2,diameter2);
    fill(r3,g3,b3);
    circle(x3,y3,diameter3);
}

//obstacle movement (1)
function o1movement(farEdgex,closeEdgex,farEdgey,closeEdgey){
    if (o1x>= farEdgex) {
        o1x=closeEdgex;
    }
    else if(o1x<= closeEdgex) {
        o1x=farEdgex;
    }
    o1x +=moveo1x;

    if (o1y>= farEdgey) {
        o1y=closeEdgey;
    }
    else if(o1y<= closeEdgey) {
        o1y=farEdgey;
    }
    o1y +=moveo1y;
}

//obstacle movement(2)
function o2movement(farEdgex,closeEdgex,farEdgey,closeEdgey){
    if (o2x>= farEdgex) {
        o2x=closeEdgex;
    }
    else if(o2x<= closeEdgex) {
        o2x=farEdgex;
    }
    o2x +=moveo2x;

    if (o2y>= farEdgey) {
        o2y=closeEdgey;
    }
    else if(o2y<= closeEdgey) {
        o2y=farEdgey;
    }
    o2y +=moveo2y;
}

//obstacle movement (3)
function o3movement(farEdgex,closeEdgex,farEdgey,closeEdgey){
    if (o3x>= farEdgex) {
        o3x=closeEdgex;
    }
    else if(o3x<= closeEdgex) {
        o3x=farEdgex;
    }
    o3x +=moveo3x;

    if (o3y>= farEdgey) {
        o3y=closeEdgey;
    }
    else if(o3y<= closeEdgey) {
        o3y=farEdgey;
    }
    o3y +=moveo3y;
}

//exit
function exit(red,green,blue,x,y,width,length,fontSize,textx,texty){
    fill(red,green,blue);
    ellipse(x,y,width,length);
    textSize(fontSize);
    text('exit. -->',textx,texty);
}

//win detection
function winDetection(px,exitLeft,exitRight,py,exitTop,exitBottom){
if (px>=exitLeft && px<=exitRight && py<=exitBottom && py>=exitTop)
    {
        winx = 570
        winy = 362.5
    }
}

//win display
function win(size,x,y){
    textSize(size);
    text("You Escaped",x,y);
}