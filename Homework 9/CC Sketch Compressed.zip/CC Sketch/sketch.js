function setup()
{
    createCanvas(1475,700);
}
function draw()
{
    background(220);
    textSize(30);
    text('Nathan Tuinstra',1250,675);
    textSize(40);
    text('My Very Accurate',1,630);
    text('and Precise Self Portrait',1,675)
    strokeWeight(20);
    line(537.5,250,612.5,475);
    line(937.5,250,862.5,475);
    circle(557.5,370,90);
    circle(917.5,370,90);
    circle(547.5,300,120);
    circle(927.5,300,120);
    ellipse(737.5,750,500,200);
    ellipse(737.5,670,100,300);
    circle(637.5,400,100);
    circle(837.5,400,100);
    circle(737.5,475,250);
    circle(737.5,250,400);
    triangle(707.5,430,737.5,250,767.5,430);
    ellipse(647.5,250,140,80);
    circle(647.5,250,80);
    point(647.5,250);
    ellipse(827.5,250,140,80);
    circle(827.5,250,80);
    point(827.5,250);
    ellipse(737.5,510,200,70);
    rect(587.5,180,120,15);
    rect(767.5,180,120,15);
    ellipse(557.5,140,50,90);
    ellipse(917.5,140,50,90);
    ellipse(577.5,110,50,90);
    ellipse(897.5,110,50,90);
    ellipse(737.5,70,390,50);
    ellipse(737.5,50,300,40);
    ellipse(737.5,30,200,40);
    line(647.5,510,827.5,510);
}