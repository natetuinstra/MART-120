var x1= 647.5;
var x2= 827.5;

var y1=180;
var y2=180;

var x1y=737.5;
var xy1=510;

var movementx1;
var movementx2;

var movementy1;
var movementy2;

var movementx1y;
var movementxy1;

var size = 30;
var count = 0;
var sizeDirection = 2;

function setup()
{
    createCanvas(1475,700);
    movementx1 = (random(0.5,1.5));
    movementx2 = (random(0.5,1.5));
    movementy1 = (random(.25,1));
    movementy2 = (random(.25,1));
    movementx1y = (random(.5,2));
    movementxy1 = (random(.5,2));
}
function draw()
{
    background(220);
    textSize(30);
    text('Nathan Tuinstra',1250,675);
    textSize(text);
    strokeWeight(20);
    line(537.5,250,612.5,475);
    line(937.5,250,862.5,475);
    circle(557.5,370,90);
    circle(917.5,370,90);
    circle(547.5,300,120);
    circle(927.5,300,120);
    ellipse(737.5,750,500,200);
    ellipse(737.5,670,100,300);
    circle(637.5,400,100);
    circle(837.5,400,100);
    circle(737.5,475,250);
    circle(737.5,250,400);
    triangle(707.5,430,737.5,250,767.5,430);
    ellipse(647.5,250,140,80);
    circle(647.5,250,80);
    point(x1,250);
    ellipse(827.5,250,140,80);
    circle(827.5,250,80);
    point(x2,250);
    ellipse(x1y,xy1,200,70);
    rect(587.5,y1,120,15);
    rect(767.5,y2,120,15);
    ellipse(557.5,140,50,90);
    ellipse(917.5,140,50,90);
    ellipse(577.5,110,50,90);
    ellipse(897.5,110,50,90);
    ellipse(737.5,70,390,50);
    ellipse(737.5,50,300,40);
    ellipse(737.5,30,200,40);
    ellipse(x1y,xy1,190,1);
    if (x1>= 687.5 || x1<= 607.5) {
        movementx1*= -1;
    }
    x1 +=movementx1;

    if (x2>= 867.5 || x2<= 787.5) {
        movementx2*= -1;
    }
    x2 +=movementx2;



    if (y1>= 190 || y1<= 170) {
        movementy1*= -1;
    }
    y1 +=movementy1;

    if (y2>= 190 || y2<= 170) {
        movementy2*= -1;
    }
    y2 +=movementy2;



    if (x1y>= 747.5 || x1y<= 727.5) {
        movementx1y*= -1;
    }
    x1y +=movementx1y;

    if (xy1>= 515 || xy1<= 505) {
        movementxy1*= -1;
    }
    xy1 +=movementxy1;



    textSize(size);
    size+= sizeDirection;
    count++;
    if(count > 5)
    {
        sizeDirection *=-1;
        count = 0;
    }
    text('My Very Accurate',1,630);
    text('and Precise Self Portrait',1,675);
}