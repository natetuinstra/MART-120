//player variables
var playerx = 50;
var playery = 50;

//obstacle arrays
var oXs = [];
var oYs = [];
var oDiameters = [];
var oR = [];
var oG = [];
var oB = [];

var moveoXs = [];
var moveoYs = [];

//shield variables
var mousex = -50;
var mousey = -50;

//win text variables
var winx = -50;
var winy = -50;

function setup()
{
    createCanvas(1480,725);

    //creates all obstacles
    var x = 740
    var y = 362.5
    var diameter = 20
    var r = 255
    var g = 0
    var b = 0
    for(var i = 0; i < 6; i++)
        {
            oXs[i] = x;
            oYs[i] = y;
            oDiameters[i] = diameter;
            diameter += 20;
            oR[i] = r;
            r += 0;
            oG[i] = g;
            g += 40;
            oB[i] = b;
            b += 0;
    //sets obstacls in motion
            moveoXs[i] = (random(-7,7));
            moveoYs[i] = (random(-7,7));
        }
}

function draw()
{
background(0);
//allows for creation of obstacles
for(var i = 0; i < oXs.length; i++)
    {
        fill(oR[i],oG[i],oB[i]);
        circle(oXs[i],oYs[i],oDiameters[i]);

        //keeps objects moving
        oXs[i] += moveoXs[i];
        oYs[i] += moveoYs[i];

        //brings obstacles to opposite edge if they go off screen
        if (oXs[i]>= 1480) {
            oXs[i]=0;
        }
        else if(oXs[i]<= 0) {
            oXs[i]=1480;
        }
    
        if (oYs[i]>= 725) {
            oYs[i]=0;
        }
        else if(oYs[i]<= 0) {
            oYs[i]=725;
        }
    }

//calls border
border(50,50,50, 0,0,1480,10, 1470,0,10,725, 0,715,1480,10, 0,0,10,715)

//calls player
player(151,200,250,playerx,playery,10)

//calls player movement
playerMove(83,65,87,68,2)

//calls sheild (mouse placement)
sheild(255,255,255,mousex,mousey,50)

//calls exit
exit(255,255,255,1480,675,30,60,20,1390,680);

//calls win detection
winDetection(playerx,1465,1495,playery,645,705)

//calls win 
win(50,winx,winy)
}
//^end of draw function^

//border
function border(red,green,blue,x1,y1,length1,width1,x2,y2,length2,width2,x3,y3,length3,width3,x4,y4,length4,width4){
fill(red,green,blue);
rect(x1,y1,length1,width1);
rect(x2,y2,length2,width2);
rect(x3,y3,length3,width3);
rect(x4,y4,length4,width4);
}

//player
function player(red,green,blue,x,y,diameter){
    fill(red,green,blue);
    circle(x,y,diameter);
}

//player movement
function playerMove(w,a,s,d,speed){
    if (keyIsDown(a)) {
        playerx -= speed;
      } else if (keyIsDown(d)) {
        playerx += speed;
      }

      if (keyIsDown(s)) {
        playery -= speed;
      } else if (keyIsDown(w)) {
        playery += speed;
      }
}

//player dash
function keyPressed(){
    if (key == " " && keyIsDown(65))
    {
        playerx-=20;
    }
    else if(key == " " && keyIsDown(68))
    {
        playerx+=20;
    }
    else if(key == " " && keyIsDown(87))
    {
        playery-=20;
    }
    else if(key == " " && keyIsDown(83))
    {
        playery+=20;
    }
}

//mouse place (sheild)
function sheild(red,green,blue,x,y,size){
    fill(red,green,blue);
    square(x,y,size);
}
function mousePressed()
{
    mousex = mouseX;
    mousey = mouseY;
}

//exit
function exit(red,green,blue,x,y,width,length,fontSize,textx,texty){
    fill(red,green,blue);
    ellipse(x,y,width,length);
    textSize(fontSize);
    text('exit. -->',textx,texty);
}

//win detection
function winDetection(px,exitLeft,exitRight,py,exitTop,exitBottom){
if (px>=exitLeft && px<=exitRight && py<=exitBottom && py>=exitTop)
    {
        winx = 570
        winy = 362.5
    }
}

//win display
function win(size,x,y){
    textSize(size);
    text("You Escaped",x,y);
}